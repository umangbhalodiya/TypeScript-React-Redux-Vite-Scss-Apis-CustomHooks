export default function ManualAudit() {
  return (
    <div className="flex flex-col items-center justify-between pt-8">
      <h1 className="text-3xl">Manual Audit</h1>
    </div>
  )
}
