'use client'
import { useParams } from 'next/navigation'

export default function () {
  const { page } = useParams()
  return <div>{page}</div>
}
