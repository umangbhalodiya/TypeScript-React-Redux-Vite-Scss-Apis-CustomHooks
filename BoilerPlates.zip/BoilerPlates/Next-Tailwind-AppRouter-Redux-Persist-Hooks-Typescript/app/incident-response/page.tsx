export default function IncidentResponse() {
  return (
    <div className="flex flex-col items-center justify-between pt-8">
      <h1 className="text-3xl">Incident Response</h1>
    </div>
  )
}
