import { useMemo, useState } from 'react'

export const useCart = () => {
  const [cart, setCart] = useState(0)

  function addCart() {
    setCart((prev) => prev + 1)
  }

  const cartMemoSection = (data: any) => {
    const memoizedValue = useMemo(() => {
      console.log('rerenderred')
      return <div>Number is {cart}</div>
    }, [cart, data])

    return memoizedValue
  }

  return { addCart, cart, cartMemoSection }
}
