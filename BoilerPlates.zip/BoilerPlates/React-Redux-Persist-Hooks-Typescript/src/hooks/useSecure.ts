import CryptoJS from 'crypto-js';
const secretKey = 'f54af92d7bd32f9ee2c3a2d5f30a6357957333b7b48218d354516092275aee91';

const useSecure = () => {
  const encrypt = (obj: Object) => {
    const ciphertext = CryptoJS.AES.encrypt(JSON.stringify(obj), secretKey).toString();
    return ciphertext;
  };

  const decrypt = (ciphertext: any) => {
    const bytes = CryptoJS.AES.decrypt(ciphertext, secretKey);
    const decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    return decryptedData;
  };

  return { encrypt, decrypt };
};

export default useSecure;
