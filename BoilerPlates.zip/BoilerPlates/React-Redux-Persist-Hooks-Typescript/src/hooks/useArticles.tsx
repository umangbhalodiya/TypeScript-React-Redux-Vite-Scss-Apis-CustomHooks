import { useMemo, useState } from 'react';
import { Article, setArticleStates } from '../redux/ApiSlice/articleSlice';
import { AppDispatch, RootState } from '../redux';
import { useDispatch, useSelector } from 'react-redux';

export const useArticles = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { articles, loading } = useSelector((state: RootState) => state.articles) as {
    articles: Article[];
    loading: boolean;
  };

  function changeState() {
    dispatch(setArticleStates({ articles: [...articles, { name: 'Hello' }], loading: true }));
  }

  const cartMemoSection = () => {
    const memoizedValue = useMemo(() => {
      return (
        <div>
          <div>Total Articles {articles?.length}</div>
          <div>Loading : {loading ? 'Yes' : 'No'}</div>
        </div>
      );
    }, [articles]);

    return memoizedValue;
  };

  return { changeState, cartMemoSection };
};
