import { useSelector } from 'react-redux';
import useAuth from '../../../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import { RootState } from '../../../redux';
import { useArticles } from '../../../hooks/useArticles';

export default function Register() {
  const navigate = useNavigate();
  const { user } = useSelector((state: RootState) => state.auth);
  const { changeState, cartMemoSection } = useArticles();
  const { onChangeRegister } = useAuth();

  useEffect(() => {
    if (!user?.username) {
      navigate('/register');
    }
  }, []);

  return (
    <div>
      <h1>Welcome to the Register page</h1>
      {/* <input name='username' value={user?.username} onChange={onChangeRegister} placeholder='Enter your username' /> */}
      <button onClick={changeState}>Submit</button>
      <button
        onClick={() => {
          window.location.reload();
        }}>
        Reload
      </button>
      {cartMemoSection()}
    </div>
  );
}
