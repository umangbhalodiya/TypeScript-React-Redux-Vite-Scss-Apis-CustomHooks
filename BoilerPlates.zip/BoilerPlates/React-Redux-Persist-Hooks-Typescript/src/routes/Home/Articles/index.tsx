import { useDispatch } from 'react-redux';
import React, { useEffect } from 'react';
import { fetchArticles } from '../../../redux/ApiSlice/articleSlice';
import { AppDispatch } from '../../../redux';
import { useQuery, UseQueryResult } from '@tanstack/react-query';
import { fetchAllProducts } from '../../../api/Products/products';
import { Product } from '../../../api/Products/types';

const Articles: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { data, error, isLoading }: UseQueryResult<Product[], Error> = useQuery<Product[], Error>({
    queryKey: ['products'], // Pass the query key here
    queryFn: fetchAllProducts, // Pass the fetch function here
  });

  useEffect(() => {
    dispatch(fetchArticles());
  }, []);

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  console.log('data', data);
  return (
    <div>
      {/* <Photography />
      <Learning /> */}
    </div>
  );
};

export default Articles;
