export default function Products() {
  return (
    <div>
      <h1>Welcome to the products page</h1>
    </div>
  );
}
