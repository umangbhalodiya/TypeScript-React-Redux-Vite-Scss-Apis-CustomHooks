import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { setUserStates } from '../store/ApiSlice/authSlice';

const useAuth = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { user } = useSelector((state) => state.auth);

  const onChangeRegister = (e) => {
    dispatch(setUserStates({ user: { ...user, [e.target.name]: e.target.value } }));
  };

  const userLogOut = () => {
    dispatch(setUserStates({ user: { username: '', password: '' }, isLoggedIn: false }));
    localStorage.clear();
    sessionStorage.clear();
    navigate('/register');
  };

  return { onChangeRegister, userLogOut };
};

export default useAuth;
