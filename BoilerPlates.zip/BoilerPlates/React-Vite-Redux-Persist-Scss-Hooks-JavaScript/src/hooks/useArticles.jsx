import { useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setArticleStates } from '../store/ApiSlice/articleSlice';

export const useArticles = () => {
  const dispatch = useDispatch();
  const { articles, loading } = useSelector((state) => state.articles);

  function changeState() {
    dispatch(setArticleStates({ articles: [...articles, { name: 'Hello' }], loading: true }));
  }

  const cartMemoSection = () => {
    const memoizedValue = useMemo(() => {
      return (
        <div>
          <div>Total Articles {articles?.length}</div>
          <div>Loading : {loading ? 'Yes' : 'No'}</div>
        </div>
      );
    }, [articles]);

    return memoizedValue;
  };

  return { changeState, cartMemoSection };
};
