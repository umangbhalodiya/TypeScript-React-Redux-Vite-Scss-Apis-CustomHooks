import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { axiosInstance } from '../../api/axios';

const initialState = {
  articles: [],
  loading: false,
};

export const fetchArticles = createAsyncThunk('/articalSlice/fetchArticles', async (_, { rejectWithValue }) => {
  try {
    const response = await axiosInstance.get(`api`);
    return response.data;
  } catch (e) {
    return rejectWithValue(e.response.data);
  }
});

export const articalSlice = createSlice({
  name: 'articles',
  initialState: initialState,
  reducers: {
    setArticleStates: (state, action) => {
      return { ...state, ...action.payload };
    },
  },
  extraReducers(builder) {
    builder
      .addCase(fetchArticles.pending, (state) => {
        if (state.articles?.length === 0) state.loading = true;
      })
      .addCase(fetchArticles.fulfilled, (state, action) => {
        state.articles = action.payload;
        state.loading = false;
      })
      .addCase(fetchArticles.rejected, (state) => {
        state.loading = false;
      });
  },
});

export const { setArticleStates } = articalSlice.actions;
export default articalSlice.reducer;
