import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { axiosInstance } from '../../api/axios';

// Initial state
const initialState = {
  user: { username: '', password: '' },
  isLoggedIn: false,
  loading: false,
};

export const login = createAsyncThunk('/authSlice/login', async (body, { rejectWithValue }) => {
  try {
    const response = await axiosInstance.post(`api/login/`, body);
    return response.data;
  } catch (e) {
    return rejectWithValue(e.response.data);
  }
});

export const authSlice = createSlice({
  name: 'auth',
  initialState: initialState,
  reducers: {
    setUserStates: (state, action) => {
      return { ...state, ...action.payload };
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(login.pending, () => {})
      .addCase(login.fulfilled, () => {})
      .addCase(login.rejected, () => {});
  },
});

export const { setUserStates } = authSlice.actions;
export default authSlice.reducer;
