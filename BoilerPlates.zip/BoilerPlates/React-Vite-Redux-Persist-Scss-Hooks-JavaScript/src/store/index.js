import { combineReducers, configureStore } from '@reduxjs/toolkit';
import { persistReducer } from 'redux-persist';
import { allPersists } from './persists';
import articalSlice from './ApiSlice/articleSlice';
import authSlice from './ApiSlice/authSlice';

const auhtPersister = persistReducer(allPersists.authConfig, authSlice);
const articlesPersister = persistReducer(allPersists.articlesConfig, articalSlice);

const rootReducer = combineReducers({
  auth: auhtPersister,
  articles: articlesPersister,
});

export const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware({ serializableCheck: false }),
});

export default store;
