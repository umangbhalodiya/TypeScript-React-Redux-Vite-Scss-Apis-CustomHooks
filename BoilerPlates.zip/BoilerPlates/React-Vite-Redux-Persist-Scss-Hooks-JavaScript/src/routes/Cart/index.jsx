import { useEffect } from "react";

export default function Cart() {
  useEffect(() => {}, []);

  return (
    <div>
      <h1>Welcome to the cart page</h1>
    </div>
  );
}
