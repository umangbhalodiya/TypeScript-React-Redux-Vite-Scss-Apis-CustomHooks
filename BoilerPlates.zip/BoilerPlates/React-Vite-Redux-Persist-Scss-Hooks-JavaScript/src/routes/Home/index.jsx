import { useArticles } from '../../hooks/useArticles';
import useAuth from '../../hooks/useAuth';

export default function Home() {
  const { cartMemoSection, changeState } = useArticles();
  const { onChangeRegister } = useAuth();

  return (
    <div>
      {/* <input name='username' value={user?.username} onChange={onChangeRegister} placeholder='Enter your username' /> */}
      <h1>Welcome to the home page</h1>
      <button onClick={changeState}>Submit</button>
      {cartMemoSection()}
    </div>
  );
}
