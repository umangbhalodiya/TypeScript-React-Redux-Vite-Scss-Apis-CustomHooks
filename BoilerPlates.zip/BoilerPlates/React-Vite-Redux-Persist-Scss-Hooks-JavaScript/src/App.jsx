import './App.css';
import { RouterProvider } from 'react-router-dom';
import router from './routes/routes.jsx';
import ReduxProvider from './store/redux-provider.jsx';

function App() {
  return (
    <ReduxProvider>
      <RouterProvider router={router} />
    </ReduxProvider>
  );
}

export default App;
