import axios from 'axios';

const axiosApi = axios.create({
  baseURL: `http://localhost:5555/api/`,
});
export const axiosInstance = axiosApi;

axiosInstance.interceptors.request.use(
  (config) => {
    config.headers.Authorization = 'Bearer your_token';
    config.headers['Content-Security-Policy'] = '*';
    config.headers['Access-Control-Allow-Origin'] = '*';
    config.headers['X-Content-Type-Options'] = 'nosniff';
    config.headers['Access-Control-Allow-Methods'] = '*';
    config.headers['Access-Control-Allow-Headers'] = '*';
    config.headers['Content-Type'] = 'application/json';
    config.headers['X-Frame-Options'] = 'SAMEORIGIN';
    config.headers['ngrok-skip-browser-warning'] = true;

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

axiosInstance.interceptors.response.use(
  (response) => {
    console.log('Response:', response);
    return response;
  },
  (error) => {
    console.log('Error response:', error.response);
    if (error.response && error.response.status === 401) {
      console.log('Unauthorized, redirecting to login...');
      localStorage.clear();
      sessionStorage.clear();
      window.location.href = '/login';
      // window.location.reload();
    }
    return Promise.reject(error);
  }
);
