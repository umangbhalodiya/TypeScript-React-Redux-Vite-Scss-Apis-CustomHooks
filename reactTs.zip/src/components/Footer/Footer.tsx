export default function Footer() {
  return <div>This is Footer</div>;
}
